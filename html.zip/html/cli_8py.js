var cli_8py =
[
    [ "cli", "cli_8py.html#a2b76ce50f2d1196e962b999948ac2674", null ]
];