var case__foo_8py =
[
    [ "edit_case", "case__foo_8py.html#ac6f3e1bef0bd1999afba8388660e2fd1", null ],
    [ "func_find_var", "case__foo_8py.html#a35cf7a58f1025239949528c4297cab43", null ]
];