var sedcommand_8py =
[
    [ "sedcommand", "sedcommand_8py.html#a4bcfc13d9124b4875426f9a2837c0ecb", null ]
];