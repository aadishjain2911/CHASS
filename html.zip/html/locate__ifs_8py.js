var locate__ifs_8py =
[
    [ "locate_ifs", "locate__ifs_8py.html#a4d57b08a2ed78bf060565ea7c0d86622", null ]
];