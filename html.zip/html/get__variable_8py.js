var get__variable_8py =
[
    [ "get_variable", "get__variable_8py.html#acffadab6bf7240b65b70af641dca95e9", null ]
];