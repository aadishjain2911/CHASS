var searchData=
[
  ['readme_2emd_95',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['remove_5fcp_2epy_96',['remove_cp.py',['../remove__cp_8py.html',1,'']]]
];
