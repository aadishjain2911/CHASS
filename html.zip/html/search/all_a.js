var searchData=
[
  ['variable_50',['variable',['../namespacevariable.html',1,'']]],
  ['variable_2epy_51',['variable.py',['../variable_8py.html',1,'']]]
];
