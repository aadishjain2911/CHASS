var searchData=
[
  ['type_65',['type',['../namespacecli.html#a22e8d05830b557d4bad23cff231d0a3e',1,'cli']]]
];
