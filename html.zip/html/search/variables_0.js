var searchData=
[
  ['changed_5fvariables_57',['changed_variables',['../namespacechanged__variables.html#aab3c82be464649331bae576f27cb4c71',1,'changed_variables']]]
];
