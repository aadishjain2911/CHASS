var searchData=
[
  ['calculate_5fexpr_54',['calculate_expr',['../namespacecalculate__expr.html',1,'']]],
  ['case_5ffoo_55',['case_foo',['../namespacecase__foo.html',1,'']]],
  ['changed_5fvariables_56',['changed_variables',['../namespacechanged__variables.html',1,'']]],
  ['cli_57',['cli',['../namespacecli.html',1,'']]]
];
