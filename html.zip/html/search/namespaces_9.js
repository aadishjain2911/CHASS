var searchData=
[
  ['variable_75',['variable',['../namespacevariable.html',1,'']]]
];
