var searchData=
[
  ['edit_5fcase_104',['edit_case',['../namespacecase__foo.html#ac6f3e1bef0bd1999afba8388660e2fd1',1,'case_foo']]]
];
