var searchData=
[
  ['open_5ffile_62',['open_file',['../namespacechanged__variables.html#af47a71f0400d06691482368c8c66a6e7',1,'changed_variables']]]
];
