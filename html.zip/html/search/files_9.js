var searchData=
[
  ['variable_2epy_99',['variable.py',['../variable_8py.html',1,'']]]
];
