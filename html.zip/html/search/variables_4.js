var searchData=
[
  ['new_5fline_5fnumber_61',['new_line_number',['../namespacechanged__variables.html#abc3f6d70c1dfd9c549ecd1848ea42b99',1,'changed_variables']]]
];
