var searchData=
[
  ['prev_63',['prev',['../namespacechanged__variables.html#a80933270a9bcc18f54722bdef3a8f5bf',1,'changed_variables']]],
  ['prev_5fline_5fnumber_64',['prev_line_number',['../namespacechanged__variables.html#a87b503b34d5c064ed31cb54a13a82c8d',1,'changed_variables']]]
];
