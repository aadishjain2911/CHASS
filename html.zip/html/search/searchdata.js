var indexSectionsWithContent =
{
  0: "cefgilprsuvw",
  1: "cfgilprsuvw",
  2: "cfgilprsuvw",
  3: "cefgilprsuw",
  4: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Files",
  3: "Functions",
  4: "Pages"
};

