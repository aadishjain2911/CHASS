var searchData=
[
  ['identify_5ffunctions_2epy_86',['identify_functions.py',['../identify__functions_8py.html',1,'']]],
  ['identify_5fvariables_2epy_87',['identify_variables.py',['../identify__variables_8py.html',1,'']]],
  ['if_5felse_2epy_88',['if_else.py',['../if__else_8py.html',1,'']]]
];
