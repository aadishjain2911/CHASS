var variable_8py =
[
    [ "funcvar", "variable_8py.html#af0099f493d96a67d8f4aa6a1e2ee2f02", null ]
];